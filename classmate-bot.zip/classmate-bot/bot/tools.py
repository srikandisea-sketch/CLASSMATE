from datetime import datetime, date, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import csv, io, json, urllib.request

WIB = ZoneInfo("Asia/Jakarta")

class ScheduleTools:
    """Read-only schedule tools. Data is loaded from JSON or an optional published CSV URL."""
    def __init__(self, config):
        self.config = config
        self.root = Path(config["project_root"])
        self.schedule_path = self.root / config.get("schedule_path", "data/schedule.json")

    def _load_data(self):
        csv_url = self.config.get("schedule_csv_url", "").strip()
        if csv_url:
            try:
                with urllib.request.urlopen(csv_url, timeout=8) as response:
                    raw = response.read().decode("utf-8-sig")
                rows = list(csv.DictReader(io.StringIO(raw)))
                sessions, assignments = [], []
                for row in rows:
                    sessions.append({
                        "date": row.get("date", ""), "start_time": row.get("start_time", ""),
                        "end_time": row.get("end_time", ""), "topic": row.get("topic", ""),
                        "room": row.get("room", ""), "online_link": row.get("online_link", ""),
                        "materials": [v.strip() for v in row.get("materials", "").split(";") if v.strip()]
                    })
                    if row.get("assignment_title"):
                        assignments.append({"title": row["assignment_title"], "due_date": row.get("due_date", ""),
                                            "description": row.get("assignment_description", ""),
                                            "related_topic": row.get("topic", "")})
                return {"course": "English for Productivity", "sessions": sessions, "assignments": assignments}
            except Exception:
                pass  # Fall back to the trusted local JSON if the CSV cannot be fetched.
        with self.schedule_path.open("r", encoding="utf-8") as f:
            return json.load(f)

    @staticmethod
    def _today():
        return datetime.now(WIB).date()

    def get_current_datetime(self):
        """Return current date and time in the Asia/Jakarta timezone."""
        now = datetime.now(WIB)
        return {"timezone": "Asia/Jakarta (WIB)", "datetime": now.isoformat(),
                "readable": now.strftime("%A, %d %B %Y, %H:%M WIB")}

    def get_schedule(self, date_or_range):
        """Get sessions for an ISO date, weekday, or range such as today, tomorrow, this week, next week."""
        today = self._today()
        query = str(date_or_range or "").strip().lower()
        start = end = today
        if query in ("this week", "week", "minggu ini"):
            start = today - timedelta(days=today.weekday()); end = start + timedelta(days=6)
        elif query in ("next week", "minggu depan"):
            start = today - timedelta(days=today.weekday()) + timedelta(days=7); end = start + timedelta(days=6)
        elif query in ("tomorrow", "besok"):
            start = end = today + timedelta(days=1)
        elif query not in ("today", "hari ini", ""):
            try:
                if " to " in query:
                    a, b = query.split(" to ", 1); start, end = date.fromisoformat(a.strip()), date.fromisoformat(b.strip())
                else:
                    start = end = date.fromisoformat(query)
            except ValueError:
                weekdays = {"monday":0,"tuesday":1,"wednesday":2,"thursday":3,"friday":4,"saturday":5,"sunday":6,
                            "senin":0,"selasa":1,"rabu":2,"kamis":3,"jumat":4,"sabtu":5,"minggu":6}
                day_index = next((v for k,v in weekdays.items() if k in query), None)
                if day_index is None:
                    return {"error":"Date or range not recognized. Use YYYY-MM-DD, today, tomorrow, this week, next week, or a weekday."}
                start = end = today + timedelta(days=(day_index - today.weekday()) % 7)
        data = self._load_data()
        matches = []
        for item in data.get("sessions", []):
            try: d = date.fromisoformat(item["date"])
            except (ValueError, KeyError, TypeError): continue
            if start <= d <= end: matches.append(item)
        matches.sort(key=lambda x:(x.get("date",""),x.get("start_time","")))
        return {"range":{"start":start.isoformat(),"end":end.isoformat()},"sessions":matches,"count":len(matches),
                "note":"An empty result means no matching sessions are recorded; do not infer that a class is cancelled."}

    def get_next_class(self):
        """Return the next recorded class at or after the current WIB time."""
        now = datetime.now(WIB); future = []
        for item in self._load_data().get("sessions", []):
            try:
                d = date.fromisoformat(item["date"])
                start = datetime.combine(d, datetime.strptime(item.get("start_time","00:00"),"%H:%M").time(), WIB)
            except (ValueError, TypeError): continue
            if start >= now: future.append((start,item))
        future.sort(key=lambda pair:pair[0])
        if not future:
            return {"next_class":None,"message":"No upcoming class is recorded. Contact the teacher to confirm."}
        return {"next_class":future[0][1],"timezone":"Asia/Jakarta (WIB)"}

    def get_assignments(self, due_within_days=7):
        """Return recorded assignments due between today and the requested number of days from today."""
        try: days = max(0,min(int(due_within_days),365))
        except (TypeError,ValueError): days = 7
        today = self._today(); end = today + timedelta(days=days); found = []
        for item in self._load_data().get("assignments", []):
            try: due = date.fromisoformat(item["due_date"])
            except (ValueError,KeyError,TypeError): continue
            if today <= due <= end: found.append({**item,"days_until_due":(due-today).days})
        found.sort(key=lambda x:x.get("due_date",""))
        return {"from":today.isoformat(),"through":end.isoformat(),"assignments":found,"count":len(found),
                "note":"Only assignments recorded in the schedule file are included."}

    def get_class_info(self, topic):
        """Find recorded room, materials, and online link for a class topic."""
        query = str(topic or "").lower().strip(); matches = []
        for item in self._load_data().get("sessions", []):
            haystack = f"{item.get('topic','')} {item.get('date','')}".lower()
            if query and (query in haystack or any(w in haystack for w in query.split() if len(w)>3)):
                matches.append({k:item.get(k) for k in ("date","start_time","end_time","topic","room","online_link","materials")})
        return {"matches":matches,"count":len(matches),"note":"If no match is found, do not guess; ask the student to contact the teacher."}
