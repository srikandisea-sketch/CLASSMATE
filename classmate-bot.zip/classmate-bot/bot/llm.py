from google import genai
from google.genai import types

class FriendlyBotError(Exception):
    """A safe, user-facing error message."""

def _friendly_error(exc):
    msg = str(exc).lower()
    if "429" in msg or "resource_exhausted" in msg or "rate limit" in msg:
        return FriendlyBotError("Gemini is receiving too many requests right now. Please wait a little and try again.")
    if any(x in msg for x in ("connection","network","timeout","unavailable")):
        return FriendlyBotError("I can’t reach Gemini right now. Please check your internet connection and try again.")
    return FriendlyBotError("I couldn’t get a response from Gemini. Please try again shortly. If schedule data is urgent, contact your teacher.")

class ClassMateLLM:
    def __init__(self, api_key, model, system_prompt, schedule_tools, generation):
        if not api_key:
            raise FriendlyBotError("Gemini API key is missing. Add GEMINI_API_KEY to your local .env file, then restart Streamlit.")
        self.client = genai.Client(api_key=api_key)
        self.model, self.system_prompt, self.tools, self.generation = model, system_prompt, schedule_tools, generation

    def _tool_functions(self):
        # google-genai derives callable schemas from these documented Python functions.
        return [self.tools.get_schedule, self.tools.get_next_class, self.tools.get_assignments,
                self.tools.get_class_info, self.tools.get_current_datetime]

    def reply(self, prior_messages, user_message, language_mode="English only"):
        window = max(0, int(self.generation.get("history_window", 10)))
        recent = prior_messages[-window:] if window else []
        contents = []
        for msg in recent:
            contents.append(types.Content(role="user" if msg.get("role")=="user" else "model",
                                          parts=[types.Part(text=msg.get("content",""))]))
        contents.append(types.Content(role="user", parts=[types.Part(text=f"Reply language mode: {language_mode}.\nStudent message: {user_message}")]))
        config = types.GenerateContentConfig(
            system_instruction=self.system_prompt,
            temperature=float(self.generation.get("temperature",0.3)),
            max_output_tokens=int(self.generation.get("max_output_tokens",500)),
            top_p=float(self.generation.get("top_p",0.9)),
            top_k=int(self.generation.get("top_k",40)),
            tools=self._tool_functions()
        )
        allowed = {"get_schedule":self.tools.get_schedule,"get_next_class":self.tools.get_next_class,
                   "get_assignments":self.tools.get_assignments,"get_class_info":self.tools.get_class_info,
                   "get_current_datetime":self.tools.get_current_datetime}
        try:
            # Function-calling loop: request -> tool call -> execute local function ->
            # send function response to Gemini -> repeat until final natural-language text.
            # The round limit prevents an accidental infinite loop.
            for _ in range(6):
                response = self.client.models.generate_content(model=self.model, contents=contents, config=config)
                if not response.candidates:
                    raise FriendlyBotError("Gemini returned an empty response. Please try again.")
                model_content = response.candidates[0].content
                if model_content: contents.append(model_content)
                calls = response.function_calls or []
                if not calls:
                    answer = (response.text or "").strip()
                    if answer: return answer
                    raise FriendlyBotError("Gemini returned an empty response. Please try again.")
                result_parts = []
                for call in calls:
                    fn = allowed.get(call.name)
                    try:
                        result = fn(**dict(call.args or {})) if fn else {"error":"Unknown tool."}
                    except Exception:
                        result = {"error":"The schedule tool could not read the data. Contact the teacher."}
                    result_parts.append(types.Part.from_function_response(name=call.name, response={"result":result}))
                contents.append(types.Content(role="user", parts=result_parts))
            raise FriendlyBotError("I couldn’t finish checking the schedule. Please try again, or contact your teacher.")
        except FriendlyBotError:
            raise
        except Exception as exc:
            raise _friendly_error(exc) from None
