from pathlib import Path
import yaml

ROOT = Path(__file__).resolve().parents[1]

def load_app_config():
    with (ROOT / "config.yaml").open("r", encoding="utf-8") as f:
        config = yaml.safe_load(f) or {}
    prompt_path = ROOT / config.get("system_prompt_path", "prompts/system_prompt.txt")
    config["system_prompt"] = prompt_path.read_text(encoding="utf-8")
    config["project_root"] = str(ROOT)
    return config

def get_available_models(config):
    return config.get("available_models") or ["gemini-2.5-flash"]
