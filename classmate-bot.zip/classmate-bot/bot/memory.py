import streamlit as st

def get_profile():
    if "student_profile" not in st.session_state:
        st.session_state.student_profile = {"name": "", "group": "", "preferred_language": "English"}
    return st.session_state.student_profile

def remember_profile(name, group, preferred_language):
    st.session_state.student_profile = {
        "name": (name or "").strip(), "group": (group or "").strip(),
        "preferred_language": preferred_language or "English"
    }

def clear_session():
    for key in ("messages", "pending_prompt"):
        st.session_state.pop(key, None)
