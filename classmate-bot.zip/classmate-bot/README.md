# ClassMate: English Productivity Schedule Assistant

ClassMate is a Streamlit chatbot prototype for an **English for Productivity** class. Students ask in natural language about recorded class times, rooms, materials, and deadlines. Gemini uses function calling to retrieve data from local JSON or an optional Google Sheets CSV URL instead of inventing details.

> **Important:** The included timetable, deadlines, and online link are demonstration data. Verify and replace them before using the app with real students.

## Features
- Streamlit chat UI, welcome message, quick replies, and sidebar settings.
- Official `google-genai` SDK and Gemini function calling.
- Tools: `get_schedule`, `get_next_class`, `get_assignments`, `get_class_info`, `get_current_datetime`.
- Grounded schedule answers; missing information is reported as unrecorded.
- English-first and optional bilingual answers.
- Session-only name, group, and language memory.
- Upcoming assignment panel with deadlines within three days highlighted.
- Adjustable Gemini model, temperature, token limit, top-p, and top-k.
- Optional Google Sheets CSV source with local JSON fallback.
- Friendly errors for missing keys, rate limits, network problems, and empty responses.

## Creative parameters

| Parameter | Default | Purpose |
|---|---|---|
| Language style | Friendly-formal teacher voice | Encouraging, respectful, never condescending |
| English level | CEFR B1 | Clear, simple language |
| Language mode | English only / Bilingual | English first; short Indonesian clarification when enabled |
| Domain | English learning + productivity | Pomodoro, SMART goals, time management, study planning |
| Memory | Streamlit session state | Name, class group, preferred language; session only |
| Recommendation | One tip after schedule/assignment answers | Turns information into an action |
| Temperature | 0.3 | Consistent responses |
| Max output tokens | 500 | Concise answers |
| Top-p / Top-k | 0.9 / 40 | Sampling controls |
| History window | Last 10 messages | Bounded context |
| Time zone | Asia/Jakarta (WIB) | Relative date interpretation |
| Guardrails | Schedule-grounded, class-focused | No invented class facts or other-student data |

## Architecture

```mermaid
flowchart TD
    A[Student in Streamlit UI] --> B[Chat history and session profile]
    B --> C[ClassMateLLM]
    C --> D[Gemini API]
    D -->|Function call| E[Python schedule tools]
    E --> F[(schedule.json or Google Sheets CSV)]
    F --> E
    E -->|Function response| D
    D -->|Final answer| C
    C --> B
    B --> A
```

The loop in `bot/llm.py` sends the request and callable tools to Gemini, executes requested Python functions, sends results back as function responses, and repeats until final text is returned. A six-round limit prevents an endless loop.

## Installation

### 1. Install Python
Install Python 3.10+ from [python.org](https://www.python.org/downloads/). On Windows, enable **Add Python to PATH**.

### 2. Download the project
```bash
git clone https://github.com/YOUR-USERNAME/classmate-bot.git
cd classmate-bot
```

### 3. Create a virtual environment
Windows PowerShell:
```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
```

### 4. Install dependencies
```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

### 5. Get a Gemini API key
1. Visit [Google AI Studio](https://aistudio.google.com/) and sign in.
2. Find the API key creation option and create a key.
3. Copy `.env.example` to a new file named `.env`.
4. Replace the placeholder with your private key:
```dotenv
GEMINI_API_KEY=PASTE_YOUR_PRIVATE_KEY_HERE
```
Never commit `.env` or reveal the key in screenshots. `.gitignore` excludes it.

### 6. Run the app and tests
```bash
streamlit run app.py
```
Open the local URL shown in the terminal (usually `http://localhost:8501`) if a browser does not open automatically.
```bash
pytest -q
```
Tests check the data and tools; they do not call Gemini.

## Edit the schedule
Edit `data/schedule.json`. Use ISO dates (`YYYY-MM-DD`), 24-hour times (`HH:MM`), and valid JSON. A session looks like:
```json
{
  "date": "2026-10-13",
  "start_time": "16:00",
  "end_time": "17:00",
  "topic": "Productivity and Goal Setting",
  "room": "Room 204",
  "online_link": "",
  "materials": ["Course overview", "SMART goals worksheet"]
}
```
Add sessions to `sessions`; add assignments to `assignments` with `title`, `due_date`, and `description`. `related_topic` is optional. Leave unknown room/link fields blank. Refresh the app after editing.

### Optional Google Sheets CSV
Create columns `date`, `start_time`, `end_time`, `topic`, `room`, `online_link`, `materials`, `assignment_title`, `due_date`, and `assignment_description`. Separate multiple materials with semicolons. Publish/export the sheet as CSV, then set `schedule_csv_url` in `config.yaml`. One CSV row represents one class session, with an optional assignment attached to that row. If CSV loading fails, the app falls back to local JSON. Publish only information appropriate for students.

## Sample conversations
- **Student:** When is our next class?  
  **ClassMate:** Checks WIB time and the next recorded session; reports only details found in the data.
- **Student:** Jadwal speaking class besok jam berapa?  
  **ClassMate:** Checks tomorrow's records and, in bilingual mode, adds a short Indonesian clarification.
- **Student:** What homework is due this week?  
  **ClassMate:** Lists recorded assignments and due dates, then suggests one planning tip.
- **Student:** Is there class on Friday? Which room?  
  **ClassMate:** Checks Friday's record. If no class/room is recorded, it says the data does not confirm it and asks the student to contact the teacher.

## Screenshots
Save screenshots in `screenshots/`:
- `01-home.png` — welcome, header, quick replies.
- `02-sidebar.png` — settings and upcoming deadlines.
- `03-next-class.png` — next-class answer.
- `04-bilingual.png` — Indonesian question and bilingual answer.
- `05-homework.png` — assignment answer and tip.

Replace these placeholders with actual images:
```markdown
![Home screen](screenshots/01-home.png)
![Sidebar and deadlines](screenshots/02-sidebar.png)
![Next class](screenshots/03-next-class.png)
![Bilingual answer](screenshots/04-bilingual.png)
![Homework](screenshots/05-homework.png)
```

## Limitations
- Gemini free-tier quotas and availability vary by account, region, and Google policy. The app handles 429 errors but cannot guarantee unlimited use.
- Model availability may change; select a model enabled for your API key.
- Accuracy depends on the teacher maintaining the source file.
- Profile memory is session-only; there is no permanent student database.
- CSV import is a small prototype, not a full Sheets API integration or permission manager.
- The app does not send notifications or create calendar events.
- Sample dates and the online link are placeholders and must be replaced before real use.

## Future improvements
- Teacher-only schedule editor and audit history.
- Authenticated Google Sheets API integration.
- Calendar integration and opt-in reminders.
- Consent-based persistent profiles.
- More tests for date parsing, CSV sources, and live API integration.

## Project structure
```text
classmate-bot/
├── app.py
├── bot/{__init__.py, config.py, llm.py, memory.py, tools.py}
├── data/schedule.json
├── prompts/system_prompt.txt
├── config.yaml
├── requirements.txt
├── .env.example
├── .gitignore
├── tests/test_tools.py
├── screenshots/.gitkeep
└── README.md
```

## GitHub safety
Never commit `.env`, API keys, private student information, or private class links. If a key is exposed, revoke it in Google AI Studio and create another one.
