import os
import streamlit as st
from dotenv import load_dotenv
from bot.config import load_app_config, get_available_models
from bot.tools import ScheduleTools
from bot.llm import ClassMateLLM, FriendlyBotError
from bot.memory import remember_profile, get_profile, clear_session

load_dotenv()
st.set_page_config(page_title="ClassMate | English for Productivity", page_icon="📚", layout="wide")
CONFIG = load_app_config()
st.title("📚 ClassMate")
st.caption("English Productivity Schedule Assistant · Your friendly class and study companion")

if "messages" not in st.session_state:
    st.session_state.messages = [{"role": "assistant", "content": "Hello! I’m ClassMate, your English for Productivity assistant. Ask me about our next class, homework, rooms, or a quick study tip. 😊"}]
if "student_profile" not in st.session_state:
    st.session_state.student_profile = {"name": "", "group": "", "preferred_language": "English"}

tools = ScheduleTools(CONFIG)
defaults = CONFIG.get("generation", {})
with st.sidebar:
    st.header("⚙️ Settings")
    profile = get_profile()
    student_name = st.text_input("Your name", value=profile.get("name", ""), placeholder="e.g. Alex")
    group = st.text_input("Class group (optional)", value=profile.get("group", ""), placeholder="e.g. Group A")
    language_mode = st.radio("Reply language", ["English only", "Bilingual"], index=1 if profile.get("preferred_language") == "Bilingual" else 0)
    remember_profile(student_name, group, "Bilingual" if language_mode == "Bilingual" else "English")
    models = get_available_models(CONFIG)
    default_model = CONFIG.get("model", "gemini-2.5-flash")
    selected_model = st.selectbox("Gemini model", models, index=models.index(default_model) if default_model in models else 0)
    st.divider()
    st.subheader("Generation parameters")
    temperature = st.slider("Temperature", 0.0, 1.0, float(defaults.get("temperature", 0.3)), 0.05)
    max_tokens = st.slider("Max output tokens", 100, 2000, int(defaults.get("max_output_tokens", 500)), 50)
    top_p = st.slider("Top-p", 0.1, 1.0, float(defaults.get("top_p", 0.9)), 0.05)
    top_k = st.slider("Top-k", 1, 100, int(defaults.get("top_k", 40)), 1)
    st.divider()
    st.subheader("📌 Upcoming this week")
    upcoming = tools.get_assignments(7)
    urgent = [a for a in upcoming.get("assignments", []) if a.get("days_until_due") is not None and a["days_until_due"] <= 3]
    if urgent:
        for item in urgent:
            st.warning(f"**{item['title']}**\n\nDue: {item['due_date']}")
    elif upcoming.get("assignments"):
        for item in upcoming["assignments"]:
            st.info(f"**{item['title']}**\n\nDue: {item['due_date']}")
    else:
        st.success("No recorded assignments due in the next 7 days.")
    if st.button("🧹 Clear chat", use_container_width=True):
        clear_session()
        st.rerun()

st.subheader("Chat")
quick_cols = st.columns(4)
quick_prompts = ["Next class", "This week's schedule", "Homework due", "Productivity tip"]
prompt_map = {
    "Next class": "When is our next class?",
    "This week's schedule": "Show this week's schedule.",
    "Homework due": "What homework is due this week?",
    "Productivity tip": "Give me a short productivity tip for studying English."
}
for col, label in zip(quick_cols, quick_prompts):
    if col.button(label, use_container_width=True):
        st.session_state.pending_prompt = prompt_map[label]

for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

typed_prompt = st.chat_input("Ask about classes, deadlines, rooms, assignments, or study habits…")
prompt = typed_prompt or st.session_state.pop("pending_prompt", None)
if prompt:
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)
    with st.chat_message("assistant"):
        try:
            llm = ClassMateLLM(
                api_key=os.getenv("GEMINI_API_KEY"), model=selected_model,
                system_prompt=CONFIG["system_prompt"], schedule_tools=tools,
                generation={"temperature": temperature, "max_output_tokens": max_tokens,
                            "top_p": top_p, "top_k": top_k, "history_window": defaults.get("history_window", 10)}
            )
            answer = llm.reply(st.session_state.messages[:-1], prompt, language_mode)
        except FriendlyBotError as exc:
            answer = str(exc)
        except Exception:
            answer = "Sorry, I couldn’t complete that request right now. Please try again in a moment, or contact your teacher if you need confirmed class information."
        st.markdown(answer)
    st.session_state.messages.append({"role": "assistant", "content": answer})

st.divider()
st.caption(f"Made by {CONFIG.get('teacher_name', 'Your Teacher')} for English for Productivity class · Times are shown in WIB (Asia/Jakarta).")
