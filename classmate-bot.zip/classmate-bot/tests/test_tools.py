import json
from pathlib import Path
from bot.tools import ScheduleTools

ROOT = Path(__file__).resolve().parents[1]

def test_schedule_file_has_sessions_and_assignments():
    data = json.loads((ROOT / "data" / "schedule.json").read_text(encoding="utf-8"))
    assert len(data["sessions"]) >= 8
    assert len(data["assignments"]) >= 3

def test_get_schedule_iso_date():
    tools = ScheduleTools({"project_root": str(ROOT), "schedule_path": "data/schedule.json", "schedule_csv_url": ""})
    result = tools.get_schedule("2026-10-13")
    assert result["count"] == 1
    assert result["sessions"][0]["topic"] == "Productivity and Goal Setting"

def test_get_class_info_finds_topic():
    tools = ScheduleTools({"project_root": str(ROOT), "schedule_path": "data/schedule.json", "schedule_csv_url": ""})
    assert tools.get_class_info("Speaking")["count"] >= 1

def test_get_assignments_invalid_days_defaults_safely():
    tools = ScheduleTools({"project_root": str(ROOT), "schedule_path": "data/schedule.json", "schedule_csv_url": ""})
    assert "assignments" in tools.get_assignments("not-a-number")
